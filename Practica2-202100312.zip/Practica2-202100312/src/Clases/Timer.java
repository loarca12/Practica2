
package Clases;

import javax.swing.JLabel;


public class Timer extends Thread {
    
    private int horas=0;
    private int minutos=0;
    private int segundos=0;
    
    JLabel cronometro;

    public Timer(JLabel cronometro) {
        this.cronometro = cronometro;
    }
  @Override
  public void run(){
      try{
          while(true){
              if(segundos==60){
                  segundos=0;
                  minutos++;
              
              }
              if(minutos==60){
                  minutos=0;
                  horas++;
              }
              segundos++;
              cronometro.setText(horas+":"+minutos+":"+segundos);
              Thread.sleep(1000);
          }
      
      }catch(Exception ex){}
  
  }
    
   
        
        
 
}   
    

