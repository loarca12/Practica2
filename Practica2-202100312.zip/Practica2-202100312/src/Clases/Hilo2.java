
package Clases;

import javax.swing.JLabel;


public class Hilo2 extends Thread {
    private int posicionInicialX;
    private int posicionFinalX;
    private int posicionInicialY;
    private int posicionFinalY;
    private int dimensiones;
    private boolean estado;
    private JLabel pelota2;
    private int velocidad;

    public Hilo2(int posicionInicialX, int posicionFinalX, int posicionInicialY, int posicionFinalY, int dimensiones, boolean estado, JLabel pelota2, int velocidad) {
        this.posicionInicialX = posicionInicialX;
        this.posicionFinalX = posicionFinalX;
        this.posicionInicialY = posicionInicialY;
        this.posicionFinalY = posicionFinalY;
        this.dimensiones = 100;
        this.estado = true;
        this.pelota2 = pelota2;
        this.velocidad = velocidad;
    }

   
    
    
    @Override
    public void run(){
        while(estado){
            try {
                Thread.sleep(velocidad);
            } catch (Exception e) {
            }
        
        }
    
    
    }
    public void avanzar() {
        if (posicionInicialX < posicionFinalX) {
            this.pelota2.setBounds(posicionInicialX, posicionInicialY, dimensiones, dimensiones);
            posicionInicialX += 2;
        }
        if (posicionInicialY < posicionFinalY) {
            this.pelota2.setBounds(posicionInicialX, posicionInicialY, dimensiones, dimensiones);
            posicionInicialY += 2;
        }

    }
    
    
    
}
