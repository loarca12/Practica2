
package Clases;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;


public class Hilos extends Thread {
    private int posicionInicialX ;
    private int posicionFinalX;
    private int posicionInicialY;
    private int posicionFinalY;
    private int dimensiones;
    private int velocidad;
    private JLabel pelota;
    private boolean estado; 
    

    public Hilos(int posicionInicialX, int posicionFinalX, int posicionInicialY, int posicionFinalY, int velocidad, JLabel pelota) {
        this.posicionInicialX = posicionInicialX;
        this.posicionFinalX = posicionFinalX;
        this.posicionInicialY = posicionInicialY;
        this.posicionFinalY = posicionFinalY;
        this.velocidad = velocidad;
        this.pelota = pelota;
        this.estado = true;
        this.dimensiones=100;
    }
    
    
    
    
    @Override
    public void run(){
        while (estado) {
            try {
                Thread.sleep(velocidad);
                avanzar();
                
            } catch (InterruptedException ex) {
                Logger.getLogger(Hilos.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    
    }
    public void avanzar() {
        if (posicionInicialX < posicionFinalX) {
            this.pelota.setBounds(posicionInicialX, posicionInicialY, dimensiones, dimensiones);
            posicionInicialX += 2;
        }
        if (posicionInicialY < posicionFinalY) {
            this.pelota.setBounds(posicionInicialX, posicionInicialY, dimensiones, dimensiones);
            posicionInicialY += 2;
        }

    }
}
