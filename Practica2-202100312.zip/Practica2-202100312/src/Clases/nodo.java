
package Clases;

public class nodo {
    String inventarioTiempo;
    String inventarioCosto;
    String produccionTiempo;
    String produccionCosto;
    String empaquetadoTiempo;
    String empaquetadoCosto;
    String salidaTiempo;
    String salidaCosto;

    public nodo(String inventarioTiempo, String inventarioCosto, String produccionTiempo, String produccionCosto, String empaquetadoTiempo, String empaquetadoCosto, String salidaTiempo, String salidaCosto) {
        this.inventarioTiempo = inventarioTiempo;
        this.inventarioCosto = inventarioCosto;
        this.produccionTiempo = produccionTiempo;
        this.produccionCosto = produccionCosto;
        this.empaquetadoTiempo = empaquetadoTiempo;
        this.empaquetadoCosto = empaquetadoCosto;
        this.salidaTiempo = salidaTiempo;
        this.salidaCosto = salidaCosto;
    }

    public String getInventarioTiempo() {
        return inventarioTiempo;
    }

    public void setInventarioTiempo(String inventarioTiempo) {
        this.inventarioTiempo = inventarioTiempo;
    }

    public String getInventarioCosto() {
        return inventarioCosto;
    }

    public void setInventarioCosto(String inventarioCosto) {
        this.inventarioCosto = inventarioCosto;
    }

    public String getProduccionTiempo() {
        return produccionTiempo;
    }

    public void setProduccionTiempo(String produccionTiempo) {
        this.produccionTiempo = produccionTiempo;
    }

    public String getProduccionCosto() {
        return produccionCosto;
    }

    public void setProduccionCosto(String produccionCosto) {
        this.produccionCosto = produccionCosto;
    }

    public String getEmpaquetadoTiempo() {
        return empaquetadoTiempo;
    }

    public void setEmpaquetadoTiempo(String empaquetadoTiempo) {
        this.empaquetadoTiempo = empaquetadoTiempo;
    }

    public String getEmpaquetadoCosto() {
        return empaquetadoCosto;
    }

    public void setEmpaquetadoCosto(String empaquetadoCosto) {
        this.empaquetadoCosto = empaquetadoCosto;
    }

    public String getSalidaTiempo() {
        return salidaTiempo;
    }

    public void setSalidaTiempo(String salidaTiempo) {
        this.salidaTiempo = salidaTiempo;
    }

    public String getSalidaCosto() {
        return salidaCosto;
    }

    public void setSalidaCosto(String salidaCosto) {
        this.salidaCosto = salidaCosto;
    }
    
    
}
